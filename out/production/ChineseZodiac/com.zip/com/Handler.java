/**
 * Created by Hanjun Chen on 2/14/18.
 */
package com;
import com.amazonaws.services.lambda.runtime.*;


public class Handler implements RequestHandler<Object,String>{

    @Override
    public String handleRequest(Object input, Context context) {
        return get_ChineseZodiac(Integer.valueOf(input.toString()))[0];
    }

    public String[] get_ChineseZodiac(int year)
    {
        switch (year % 12) {
            case 0: return new String[]{"monkey"};
            case 1: return new String[]{"rooster"};
            case 2: return new String[]{"dog"};
            case 3: return new String[]{"pig"};
            case 4: return new String[]{"rat"};
            case 5: return new String[]{"ox"};
            case 6: return new String[]{"tiger"};
            case 7: return new String[]{"rabbit"};
            case 8: return new String[]{"dragon"};
            case 9: return new String[]{"snake"};
            case 10: return new String[]{"horse"};
            case 11: return new String[]{"sheep"};
            default: throw new IllegalArgumentException("Year format is not coorect");
        }

    }
}
